const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const gravatar = require('gravatar');
const jwt = require('jsonwebtoken');
const passport = require('passport');


const User = require('../../models/users');
const keys = require('../../config/keys');
const validateRegisterInput = require('../../validation/register');
const validateLoginInput = require('../../validation/login');

// generated data for user to show  case in the webpage..
const data = require('../../faker/fakeUserData');



// @route   GET api/users/test
// @desc    Tests users route
// @access  Public
router.get('/test', (req, res) => res.json({ msg: 'Users Works' }));


// @route   GET api/users/register
// @desc    registering users credentials form filling route
// @access  Public

router.post('/signup', (req, res)=>{
	
	User.findOne({email: req.body.email})
		.then((user) =>{
			if(user){
				return (
					res.status(400)
						.json({email: "email already exist..."})
					);
			}else{

				const avtar = gravatar.url(req.body.email , 
					{
						s: '200',
						r: 'pg',
						d: 'mm'
					});

				// adhar_no, acc_type, dob, age, full_address, zip_code, religion, mobileNo
				const newUser = new User({
					email: 		req.body.email,
					password: 	req.body.password,
					avtar: 		avtar,
					name: 		req.body.name,
					accNo: 		req.body.accNo,
					adhar_no:  	data.adhar_no,
					acc_type: 	data.acc_type,
					dob: 		data.dob,
					full_address:data.full_address,
					zip_code: 	data.zip_code,
					religion: 	data.religion,
					mobileNo: 	data.mobileNo
				})
 
				const fs = require('fs');
				fs.writeFile("./rec2/user_id/user.txt",newUser._id,function(err){
					if(err){console.log(err)}
					else{
						console.log("sucess");
					}
				})
				bcrypt.genSalt(10, (err, salt)=> {
				    bcrypt.hash(newUser.password, salt, (err, hash)=> {
				    	// if(err) throw err;
				    	newUser.password = hash;
				        newUser
				        	.save()
				        	.then((user)=> res.json(user))
				        	.catch((err)=> console.log(err))
				    });
				});
			}
		})
});


// @route   GET api/users/register
// @desc    loggin in the user
// @access  Public

router.post('/signin', (req, res)=>{

	const email = req.body.email;
	const password = req.body.password;


	User.findOne({email: email})
		.then((user)=> {
			if(!user){
				errors.email = "user not found with the given email"
				return res.status(404).json(errors);
			}

			bcrypt.compare(password, user.password)
				.then((isMatch) => {
			    	if(isMatch){
						console.log(user.id)
			    		// return res.json({ msg: "success"});
			    		const payload = { id: user.id, avtar: user.avtar, name: user.name};
						const fs = require('fs');
						fs.writeFile("./rec2/user_id/user.txt",user.id,function(err){
							if(err){console.log(err)}
							else{
								console.log("sucess");
							}
						})
			    		jwt.sign(
			    			payload, 
			    			keys.secret, 
			    			{ expiresIn: 360000}, 
			    			(err, token)=>{
			    			res.json({
								name:user.name,
								
			    				success: "true", 
								token: 'Bearer ' + token,
								id:user.id,
								accNo:user.accNo,
								email:user.email

								
			    			});
			    		});
			    	}else{
			    		errors.password = "password incorrect"
			    		return res.status(400).json(errors);
			    	}
			});
		})
});



// @route   GET api/users/curent
// @desc    Tests curent route 
// @access  private

router.get('/:id', (req, res)=>{

	console.log(req.params.id);
	User.findById(req.params.id)
		.then(response=>{
			
			res.send(response)})
		.catch(err=>console.log(err))
});


router.get("/about",(req,res)=>{
	  res.send("../../../views/about.html")
})


module.exports = router;
