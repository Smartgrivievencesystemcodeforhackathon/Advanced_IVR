		const fs = require('fs');
		const path = require('path');

		const folderPath = __dirname + '\\complaints_text';
		
		console.log(folderPath);

		fs.readdir(folderPath, function (err, files) {
		  if (err) {
		    console.log(err)
		  }
		  files.map(
		    (file) => { 
		    	const fileName  = __dirname + `\\complaints_text\\${file}`;
				const results = fs.readFileSync(fileName).toString().split("\n");

				const dept = results[0];
				console.log(dept);

				const complaintText = results[1];
				console.log(complaintText);
		    	// console.log(file) 
		    })})
