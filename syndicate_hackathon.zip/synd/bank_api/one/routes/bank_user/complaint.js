const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const passport = require('passport');

// requiring models
const User = require('../../models/users');
const Complaint = require('../../models/complaint');

// validations..
const validatePostInput = require('../../validation/post');



// test route for the complaint file  without auth
router.get('/test', (req, res) => res.json({ msg: 'Posting complain Works' }));

router.get('/issue',async (req,res,next)=>{
	    try{
			  let allIssue = await Complaint.find({});
			  res.send(allIssue);
			  return next();
		}catch(err){
			return next(err);
		}
})
// test route for the complaint file  with auth
router.post('/test', passport.authenticate('jwt', { session: false }), (req, res)=>{
	res.json(req.user.id)
	console.log(req.user.id)
});


// route for the getting total complaint done by particualr userid
router.get('/:id',(req, res) =>{

	let { id } = req.params;
	

	
		Complaint.find({ user: id })
			.sort({date: -1})
			.then(complaints => res.json(complaints))
			.catch(err => res.status(404).json({NoPostFound: "No complaints found with the given id try later..."}));
	
});

//passport.authenticate('jwt', { session: false }),
// getting single complaint by the given id of the complaint
router.get('/one/:id',  (req, res) =>{
	Complaint.findById(req.params.id)
		.then(Complaint => res.json(Complaint))
		.catch(err => res.status(404).json({NoComplaintFound: "No complaint found try later..."}));
});



router.post('/:id/new', (req, res)=>{
	
	const newComplaint = new Complaint({

		complainDept: req.body.department,
		complainDescription: req.body.description,
		complainStatus: req.body.status,
		user:req.params.id
	
	});

	newComplaint.save()
		.then(c => res.send(c))
		.catch(err=>console.log(err));
});


module.exports = router;
