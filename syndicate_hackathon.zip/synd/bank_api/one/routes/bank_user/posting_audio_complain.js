// posting_audio_complain.js

const express = require("express");
const router = express.Router();
const mongoose = require("mongoose");
const passport = require("passport");
const fs = require("fs");
const path = require("path");

// requiring models
const User = require("../../models/users");
const Complaint = require("../../models/complaint");

// validations..
const validatePostInput = require("../../validation/post");

// test route for the complaint file  without auth
router.get("/test", (req, res) => res.json({ msg: "Posting complain Works" }));

router.get("/:id/new", (req, res) => {
  

  const folderPath = __dirname + "\\complaints_text";

  console.log(folderPath);

  fs.readdir(folderPath, function(err, files) {
    if (err) {
      console.log(err);
    }
    files
      .map(file => {
        const fileName = __dirname + `\\complaints_text\\${file}`;
        const results = fs
          .readFileSync(fileName)
          .toString()
          .split("\n");

        const dept = results[0];
        const complaintText = results[1];

        const newComplaint = new Complaint({
          complainDept: dept,
          complainDescription: complaintText,
          complainStatus: false,
          user: req.params.id
        });

        newComplaint.save()
        .then(c => res.send(c))
        .then(()=>{
           fs.unlink(fileName, ()=>{ console.log("also deleted the uploaded data....")})
        })
        .catch(err => console.log(err));
      })
      
  });
});

module.exports = router;
