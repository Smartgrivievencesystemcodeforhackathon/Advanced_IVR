var faker = require('faker');
var moment = require('moment');
var ageCalculator = require('age-calculator');
let {AgeFromDateString, AgeFromDate} = require('age-calculator');

let adhar_no, acc_type, dob, age, full_address, zip_code, religion, mobileNo;

// random adhar no for user
adhar_no = Math.floor(Math.random()*Math.pow(10, 12));

// random account type for the user
no = Math.round(Math.random());
if(no == 0){
	acc_type = "saving"
}else{
	acc_type = "current"
}

// random  date  of birth for the  year
let maxMonth = 12, minMonth = 1, maxDay = 31, minDay = 1, 
	maxYear = 2005, minYear = 1965, date, month, year

date = Math.floor(Math.random() * (maxDay - minDay + 1)) + minDay;
month = Math.floor(Math.random() * (maxMonth - minMonth + 1)) + minMonth;
year = Math.floor(Math.random() * (maxYear - minYear + 1)) + minYear;
dob = date + "/" + month + "/" + year;



// calcualtating age of the user
let yearNow, monthNow, dateNow, ageYear, ageMonth, ageDate;

yearNow = moment().year();
monthNow = moment().month() + 1 ;
dateNow = moment().date()

ageYear = yearNow - year;
ageMonth = monthNow - month;
ageDate = dateNow - date;

// ===========complete it....=============


// zip_code of user
zip_code = Math.floor(Math.random()*Math.pow(10, 6));


//full address for the user
let city, streetName, streetAddress, latitude, longitude;

city = faker.address.city();
streetName = faker.address.streetName();
streetAddress = faker.address.streetAddress();
latitude = faker.address.latitude();
longitude = faker.address.longitude();

full_address = "longitude : " + longitude + "  latitude : " + latitude + "  Street Name- "
				+ streetName + "  Street Address- " + streetAddress + "  city- " +  city


// religion of the user

let decideNo, maxNo = 6, minNo = 1
decideNo = Math.floor(Math.random() * (maxNo - minNo + 1)) + minNo;

if(decideNo == 1){
	religion = "Hindu"
}else if(decideNo ==2){
	religion = "Christian"
}else if(decideNo ==3){
	religion = "Muslim"
}else if(decideNo ==4){
	religion = "Jain"
}else if(decideNo ==5){
	religion = "Scheduled Caste"
}else if(decideNo ==6){
	religion = "Scheduled Tribe"
}

// users mobileNo
let decideUnit, decideTens, remainingNo, maxFirst = 9, minFirst = 6
decideUnit = Math.floor(Math.random() * (maxFirst - minFirst + 1)) + minFirst;
decideTens = Math.floor(Math.random() * (maxFirst - minFirst + 1)) + minFirst;
remainingNo = Math.floor(Math.random()*Math.pow(10, 8));

mobileNo = decideUnit.toString() + decideTens.toString() + remainingNo.toString();


module.exports = { adhar_no, acc_type, dob, age, full_address, zip_code, religion, mobileNo };
