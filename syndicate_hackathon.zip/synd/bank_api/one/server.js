const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');

const keys = require('./config/keys');
const morgan = require('morgan');
const cors = require('cors');




// bank routes user
const users = require('./routes/bank_user/user');
const complaints = require('./routes/bank_user/complaint');
const audioComplaints = require('./routes/bank_user/posting_audio_complain');


const app = express();

app.set('view engine', 'ejs');
app.use(morgan("tiny"));
app.use(cors())
// bodyparser middleware..
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get("/about",(req,res)=>{

	  res.render('./about')
})
// db connection....
mongoose
	.connect(keys.mongoURI,{ useNewUrlParser: true })
	.then(()=> console.log('connected to database'))
	.catch((err)=> console.log(err))


// passport middleware...
app.use(passport.initialize());

require("./config/passport")(passport);

// bank_user
app.use('/user', users);
app.use('/user/complaint', complaints);
app.use('/user/audioComplaints', audioComplaints);

app.listen(keys.port, (req, res)=>{
	console.log(`listening on port ${keys.port}`);
})