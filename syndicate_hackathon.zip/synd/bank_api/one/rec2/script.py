import glob, os
cwd = os.getcwd()
new_path = cwd+"\\"+"uploads"
os.chdir(new_path) 
finalfiles = []
newfiles = {}

for file in glob.glob("*.webm"):
    finalfiles.append(file.split('.webm')[0])
for i in finalfiles:
    webmfile = i+".webm"
    wavfile = i+".wav"
    os.remove(webmfile)
    os.remove(wavfile)
