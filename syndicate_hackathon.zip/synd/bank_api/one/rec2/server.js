var http = require("http"),
  url = require("url"),
  path = require("path"),
  fs = require("fs"),
  uuid = require("node-uuid"),
  port = process.argv[2] || 7000,
  date = require("date-and-time");

console.log("http://localhost:" + port);

var app = http
  .createServer(function(request, response) {
    var uri = url.parse(request.url).pathname,
      filename = path.join(process.cwd(), uri);

    fs.exists(filename, function(exists) {
      if (!exists) {
        response.writeHead(404, {
          "Content-Type": "text/plain"
        });
        response.write("404 Not Found: " + filename + "\n");
        response.end();
        return;
      }

      if (fs.statSync(filename).isDirectory()) filename += "/index.html";

      fs.readFile(filename, "binary", function(err, file) {
        if (err) {
          response.writeHead(500, {
            "Content-Type": "text/plain"
          });
          response.write(err + "\n");
          response.end();
          return;
        }

        response.writeHead(200);
        response.write(file, "binary");
        response.end();
      });
    });
  })
  .listen(parseInt(port, 10));

var path = require("path"),
  exec = require("child_process").exec;

var io = require("socket.io").listen(app);

io.sockets.on("connection", function(socket) {
  socket.on("message", function(data) {
    var fileName = uuid.v4();

    fs.readFile("./user_id/user.txt", "utf-8", (err, user_id) => {
      const now = new Date();
      const just_now = date.format(now, "YYYY/MM/DD_HH:mm:ss");

      writeToDisk(data.audio.dataURL, "_" + user_id + "$" + fileName + ".wav");
      console.log("saving");
    });
  });
});

function writeToDisk(dataURL, fileName) {
  var fileExtension = fileName.split(".").pop(),
    fileRootNameWithBase = "./uploads/" + fileName,
    filePath = fileRootNameWithBase,
    fileID = 2,
    fileBuffer;

  filePath = fileRootNameWithBase + "(" + fileID + ")." + fileExtension;
  fileID += 1;

  dataURL = dataURL.split(",").pop();
  fileBuffer = new Buffer(dataURL, "base64");
  fs.writeFileSync(filePath, fileBuffer);
  console.log("heloo");
  console.log("filePath", filePath);
}

function merge(socket, fileName) {
  var FFmpeg = require("fluent-ffmpeg");

  var audioFile = null;
  videoFile = null;
  mergedFile = null;

  new FFmpeg({
    source: videoFile
  })
    .addInput(audioFile)
    .on("error", function(err) {
      socket.emit("ffmpeg-error", "ffmpeg : An error occurred: " + err.message);
    })
    .on("progress", function(progress) {
      socket.emit("ffmpeg-output", Math.round(progress.percent));
    })
    .on("end", function() {
      socket.emit("merged", fileName + "-merged.webm");
      console.log("Merging finished !");

      // removing audio/video files
      fs.unlink(audioFile);
      fs.unlink(videoFile);
    })
    .saveToFile(mergedFile);
}
