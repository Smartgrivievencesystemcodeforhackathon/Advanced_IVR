import speech_recognition as sr
import glob, os


cwd = os.getcwd()
#new_path = cwd+"\\"+"Desktop"+"\\"+"Rec"+"\\"+"uploads"
#os.chdir(new_path)

finalfiles = []
for file in glob.glob("*.wav"):
    finalfiles.append(file)
for i in finalfiles:
	AUDIO_FILE = i 
	r = sr.Recognizer() 

	with sr.AudioFile(AUDIO_FILE) as source: 
		#reads the audio file. Here we use record instead of 
		#listen 
		audio = r.record(source) 

	#	print("The audio file contains: " + r.recognize_google(audio))
	t2s = i.split('.wav')
	t2s = i+'.txt' 
	with open(t2s,'w') as f:
	    f.write(r.recognize_google(audio))
	f.close()