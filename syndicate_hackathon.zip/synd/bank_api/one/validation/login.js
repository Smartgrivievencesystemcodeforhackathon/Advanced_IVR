const validator = require('validator');
const isEmpty = require('./is_empty');

module.exports = validateLoginInput = (data)=>{

	let errors = {};

	data.email = !isEmpty(data.email) ? data.email : '';
	data.password = !isEmpty(data.password) ? data.password : '';

	if(!validator.isEmail(data.email)){
		errors.email = "email Filled is not correct";
	}
	
	if(validator.isEmpty(data.email)){
		errors.email = "email Must Be Filled";
	}

	if(validator.isEmpty(data.password)){
		errors.password = "password Must Be Filled";
	}

	
	return{
		errors: errors,
		isValid: isEmpty(errors)
	};
};

