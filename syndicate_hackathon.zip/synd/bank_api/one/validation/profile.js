const validator = require('validator');
const isEmpty = require('./is_empty');

module.exports = validateProfileInput = (data)=>{

	let errors = {};
	data.handle = !isEmpty(data.handle) ? data.handle : '';
	data.status = !isEmpty(data.status) ? data.status : '';
	data.skills = !isEmpty(data.skills) ? data.skills : '';


	if(!validator.isLength(data.handle, {min:2, max:40})){
		errors.handle = "Handle Must Be Given Between 2 And 40 Charchters";
	}

	if(validator.isEmpty(data.handle)){
		errors.handle = "handle Must Be Filled";
	}
	
	if(validator.isEmpty(data.status)){
		errors.status = "status Must Be Filled";
	}

	if(validator.isEmpty(data.skills)){
		errors.skills = "skills Must Be Filled";
	}

	if(!isEmpty(data.website)){
		if(!validator.isURL(data.website)){
			errors.website = "URL is Not Valid Try Another";
		}
	}

	if(!isEmpty(data.youtube)){
		if(!validator.isURL(data.youtube)){
			errors.youtube = "youtube URL is Not Valid Try Another";
		}
	}

	if(!isEmpty(data.facebook)){
		if(!validator.isURL(data.facebook)){
			errors.facebook = "facebook URL is Not Valid Try Another";
		}
	}

	if(!isEmpty(data.instagram)){
		if(!validator.isURL(data.instagram)){
			errors.instagram = "instagram URL is Not Valid Try Another";
		}
	}

	if(!isEmpty(data.linkedin)){
		if(!validator.isURL(data.linkedin)){
			errors.linkedin = "linkedin URL is Not Valid Try Another";
		}
	}

	if(!isEmpty(data.twitter)){
		if(!validator.isURL(data.twitter)){
			errors.twitter = "twitter URL is Not Valid Try Another";
		}
	}

	return{
		errors: errors,
		isValid: isEmpty(errors)
	};
};
