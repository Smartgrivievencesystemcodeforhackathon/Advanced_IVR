const validator = require('validator');
const isEmpty = require('./is_empty');

module.exports = validateRegisterInput = (data)=>{

	let errors = {};
	data.name = !isEmpty(data.name) ? data.name : '';
	data.email = !isEmpty(data.email) ? data.email : '';
	data.password = !isEmpty(data.password) ? data.password : '';
	data.password2 = !isEmpty(data.password2) ? data.password2 : '';


	if(!validator.isLength(data.name, {min:2, max:30})){
		errors.name = "Name Must Be Given Between 2 And 30 Charchters";
	}

	if(validator.isEmpty(data.name)){
		errors.name = "Name Must Be Filled";
	}

	if(!validator.isEmail(data.email)){
		errors.email = "email Filled is not correct";
	}
	
	if(validator.isEmpty(data.email)){
		errors.email = "email Must Be Filled";
	}

	

	if(validator.isEmpty(data.password)){
		errors.password = "password Must Be Filled";
	}

	if(!validator.isLength(data.password, { min:6, max:30 })){
		errors.password = "password Must Be Filled at least 6 Charchters";
	}

	if(validator.isEmpty(data.password2)){
		errors.password2 = "Confirm password Must Be Filled";
	}

	if(!validator.equals(data.password, data.password2)){
		errors.password2 = "Password Must Be Filled Same";
	}
	return{
		errors: errors,
		isValid: isEmpty(errors)
	};
};

