const validator = require('validator');
const isEmpty = require('./is_empty');

module.exports = validatePostInput = (data)=>{

	let errors = {};

	data.text = !isEmpty(data.text) ? data.text : '';

	if(!validator.isLength(data.text, {min:30, max: 300})){
		errors.text = "the text to be posted must be between 30 to 300 charachters...";
	}
	
	if(validator.isEmpty(data.text)){
		errors.text = "text Must Be Filled";
	}
	
	return{
		errors: errors,
		isValid: isEmpty(errors)
	};
};

