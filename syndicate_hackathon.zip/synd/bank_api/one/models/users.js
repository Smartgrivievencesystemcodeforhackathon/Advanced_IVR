const mongoose = require('mongoose');
const schema = mongoose.Schema;

const userModel = new schema({

	name:{
		type: String, 
		
	},
	email:{
		type: String, 
	
	},
	accNo:{
		type: String, 
	
	},
	password:{
		type: String, 
		required: true
	},
	avtar:{
		type: String, 
	},
	adhar_no:{
		type: String, 
	
	},
	acc_type:{
		type: String, 
		
	},
	full_address:{
		type: String, 
	
	},
	zip_code:{
		type: String, 
		
	},
	religion:{
		type: String, 
		
	},
	mobileNo:{
		type: String, 
		
	},
	date:{
		type: Date, 
		default: Date.now
	}
});

module.exports = User = mongoose.model('users', userModel);
