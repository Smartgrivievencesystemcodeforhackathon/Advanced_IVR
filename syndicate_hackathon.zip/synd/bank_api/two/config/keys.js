module.exports = {
  mongoURI: 'mongodb://bank:bank123@ds159400.mlab.com:59400/bank', 
  port: process.env.PORT || 9000,
  secret: "i am dolar singh",

};
