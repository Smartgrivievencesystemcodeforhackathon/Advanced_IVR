const JwtStrategy = require('passport-jwt').Strategy;
const ExtractJwt = require('passport-jwt').ExtractJwt;
const mongoose = require('mongoose');
const Admin = mongoose.model('admins');
const keys = require('./keys');

const opts = {};
opts.jwtFromRequest = ExtractJwt.fromAuthHeaderAsBearerToken();
opts.secretOrKey = keys.secret;


module.exports = passport =>{
	passport.use(new JwtStrategy(opts, (jwt_payload, done)=>{
		// console.log(jwt_payload);
		Admin.findById(jwt_payload.id)
			.then((admin)=>{
				// console.log(admin);
				if(admin){
					return done(null, admin);
				}
				return done(null, false);
			})
			.catch(err => console.log(err));
	})
  );
};
