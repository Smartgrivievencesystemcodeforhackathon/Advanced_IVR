// resolvedComplaints.js
const mongoose = require('mongoose');
const schema = mongoose.Schema;

const resolvedComplaintModel = new schema({

	user: {
	    user_id: String,
	    user_complaint_id: String 
	},
	resolvedBy:{
		type: schema.Types.ObjectId,
	    ref: 'admin'
	},
	complainDept:{
		type: String,
		required: true
	},
	complainDescription:{
		type: String,
		required: true
	},
	complainStatus:{
		type: Boolean,
        default: false
	},
	date:{
		type: Date, 
		default: Date.now
	},
});

module.exports = resolvedComplaint = mongoose.model('complaints', resolvedComplaintModel);

