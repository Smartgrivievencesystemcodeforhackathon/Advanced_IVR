const mongoose = require('mongoose');
const schema = mongoose.Schema;

const complaintModel = new schema({

	user: {
	    type: schema.Types.ObjectId,
	    ref: 'users'
	},
	complainDept:{
		type: String,
		required: true
	},
	complainDescription:{
		type: String,
		required: true
	},
	complainStatus:{
		 type: Boolean,
        default: false
	},
	date:{
		type: Date, 
		default: Date.now
	},
});

module.exports = Complaint = mongoose.model('complaints', complaintModel);

