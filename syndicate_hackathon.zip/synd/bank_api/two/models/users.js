const mongoose = require('mongoose');
const schema = mongoose.Schema;

const userModel = new schema({

	name:{
		type: String, 
		required: true
	},
	email:{
		type: String, 
		required: true
	},
	accNo:{
		type: String, 
		required: true
	},
	password:{
		type: String, 
		required: true
	},
	avtar:{
		type: String, 
	},
	adhar_no:{
		type: String, 
		required: true
	},
	acc_type:{
		type: String, 
		required: true
	},
	full_address:{
		type: String, 
		required: true
	},
	zip_code:{
		type: String, 
		required: true
	},
	religion:{
		type: String, 
		required: true
	},
	mobileNo:{
		type: String, 
		required: true
	},
	date:{
		type: Date, 
		default: Date.now
	}
});

module.exports = User = mongoose.model('users', userModel);
