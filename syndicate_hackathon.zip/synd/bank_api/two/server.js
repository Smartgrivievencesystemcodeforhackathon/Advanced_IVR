const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');

const keys = require('./config/keys');
const cors = require("cors");
const morgan = require("morgan")


// bank routes admin
const admins = require('./routes/bank_admin/admin');
const adminComplaints = require('./routes/bank_admin/allComplints');

const app = express();

// bodyparser middleware..
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


// db connection....
mongoose
	.connect(keys.mongoURI,{ useNewUrlParser: true })
	.then(()=> console.log('connected to database'))
	.catch((err)=> console.log(err))


// passport middleware...

app.use(morgan("tiny"));
app.use(cors());
app.use(passport.initialize());

require("./config/passport")(passport);

// bank_admin
app.use('/admin', admins);
app.use('/admin/complaint', adminComplaints);


app.listen(keys.port, (req, res)=>{
	console.log('listening on port 9000');
})