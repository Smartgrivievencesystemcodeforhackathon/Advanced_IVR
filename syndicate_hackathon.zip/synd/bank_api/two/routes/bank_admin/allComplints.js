const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const passport = require('passport');

// requiring models
const User = require('../../models/admins');
const Complaint = require('../../models/complaint');

// validations..
const validatePostInput = require('../../validation/post');



// test route for the complaint file  without auth
router.get('/test', (req, res) => res.json({ msg: 'getting complain  at admin Works' }));


// test route for the complaint file  with auth
router.get('/testc', passport.authenticate('jwt', { session: false }), (req, res)=>{
	res.json({id: req.user.id, name:  req.user.name, })
});

// route to get all the complaints from every user and sorted by date and time the most recent will be on top
// passport.authenticate('jwt', { session: false }), 
router.get('/all', (req, res)=>{
	Complaint.find()
			.sort({date: -1})
			.then(complaints => res.json(complaints))
			.catch(err => res.status(404).json({NoPostFound: "No complaints found with the given id try later..."}));
});


// route to get the all the complaints from a single user
// passport.authenticate('jwt', { session: false }), 
router.get('/all/:user_id', (req, res)=>{

	let { user_id } = req.params;

		Complaint.find({ user: user_id })
			.sort({date: -1})
			.then(complaints => res.json(complaints))
			.catch(err => res.status(404).json({NoPostFound: "No complaints found with the given id try later..."}));

});


// route to get the a single complaint from any user
// passport.authenticate('jwt', { session: false }), 
router.get('/one/:quest_id', (req, res)=>{

	let { quest_id } = req.params;


		Complaint.findById(quest_id)
			.then(c => res.json(c))
			.catch(err => res.status(404).json({NoPostFound: "No complaints found with the given id try later..."}));
	
});


// route to update the status of the complaint

router.post('/one/:quest_id', (req, res)=>{

	let { quest_id } = req.params;


		Complaint.findById(quest_id)
			.then((c) =>{
				let db = c.complainStatus;
				console.log(db);


				res.json(c);
			})
			.catch(err => res.status(404).json({NoPostFound: "No complaints found with the given id try later..."}));
	
});


router.post("/status/:id",(req,res)=>{
	    Complaint.findById(req.params.id)
	        .then(data=>{
	        	 data.complainStatus=true;
	        	 data.save();
	        	 res.send(data)

	        }).catch(err=>console.log(err))
})



module.exports = router;
