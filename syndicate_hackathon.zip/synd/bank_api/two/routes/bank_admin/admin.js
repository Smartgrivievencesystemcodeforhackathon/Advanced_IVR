const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const gravatar = require('gravatar');
const jwt = require('jsonwebtoken');
const passport = require('passport');
const Complaint = require('../../models/complaint');

const Admin = require('../../models/admins');
const keys = require('../../config/keys');
const validateRegisterInput = require('../../validation/register');
const validateLoginInput = require('../../validation/login');


router.get('/test', (req, res) => res.json({ msg: 'admin Works' }));



router.post('/register', (req, res)=>{

	  const { errors, isValid } = validateRegisterInput(req.body);

	  // Check Validation
	  if (!isValid) {
	    return res.status(400).json(errors);
	  }

	
	Admin.findOne({email: req.body.email})
		.then((admin) =>{
			if(admin){
				return (
					res.status(400)
						.json({email: "email already exist..."})
					);
			}else{

				const avtar = gravatar.url(req.body.email , 
					{
						s: '200',
						r: 'pg',
						d: 'mm'
					});


				const newAdmin = new Admin({
					email: 		req.body.email,
					password: 	req.body.password,
					avtar: 		avtar,
					name: 		req.body.name
				})

				bcrypt.genSalt(10, (err, salt)=> {
				    bcrypt.hash(newAdmin.password, salt, (err, hash)=> {
				    	// if(err) throw err;
				    	newAdmin.password = hash;
				        newAdmin
				        	.save()
				        	.then((admin)=> res.json(admin))
				        	.catch((err)=> console.log(err))
				    });
				});
			}
		})
});



router.post('/login', (req, res)=>{
 
	// const { errors, isValid } = validateLoginInput(req.body);

	//   // Check Validation
	//   if (!isValid) {
	//     return res.status(400).json(errors);
	//   }

	const email = req.body.email;
	const password = req.body.password;

     console.log(email+password)
	if((email === "admin-loan@gmail.com" || "admin-credit@gmail.com" || "admin-kisan@gmail.com") && password === "admin123")
	{  console.log("hello")
		Complaint.find()
			.sort({date: -1})
			.then(complaints => {
				console.log(complaints)
				res.json(complaints)})
			.catch(err => console.log(err));
	}

	
});


router.get('/current', passport.authenticate('jwt', { session: false }), (req, res)=>{
	res.json({
		name: req.user.name,
		email: req.user.email,
		id: req.user.id
	});

	// console.log(req.admin);
});



module.exports = router;
