# -*- coding: utf-8 -*-
"""
@author: b117042_pdba
"""
"""
LIBRARIES  USED
USING  TENSORFLOW  BACKEND
"""

import time
from watchdog.observers import Observer
from watchdog.events import PatternMatchingEventHandler
import pickle
import numpy as np
import pandas as pd
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
import speech_recognition as sr


#import glob, os

df = pd.read_csv("Consumer_Complaints.csv")
col = ['Product', 'Consumer complaint narrative']
df = df[col]
df = df[pd.notnull(df['Consumer complaint narrative'])]
df.columns = ['Product', 'Consumer_complaint_narrative']
#df.Product.value_counts()
#df.Issue.value_counts()--Issue is not the primary key
df.loc[df['Product'] == 'Credit reporting', 'Product'] = 'Credit card'
df.loc[df['Product'] == 'Credit card or prepaid card', 'Product'] = 'Credit card'
df.loc[df['Product'] == 'Prepaid card', 'Product'] = 'Credit card'
df.loc[df['Product'] == 'Credit reporting, credit repair services, or other personal consumer reports', 'Product'] = 'Credit card'



df.loc[df['Product'] == 'Payday loan', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Mortgage', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Debt collection', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Student loan', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Payday loan', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Vehicle loan or lease', 'Product'] = 'Consumer Loan'
df.loc[df['Product'] == 'Payday loan, title loan, or personal loan', 'Product'] = 'Consumer Loan'


df.loc[df['Product'] == 'Virtual currency', 'Product'] = 'Other financial service' 
df.loc[df['Product'] == 'Bank account or service ', 'Product'] = 'Other financial service'      
df.loc[df['Product'] == 'Checking or savings account', 'Product'] = 'Other financial service'  
df.loc[df['Product'] == 'Money transfers', 'Product'] = 'Other financial service'
df.loc[df['Product'] == 'Money transfer, virtual currency, or money service', 'Product'] = 'Other financial service'   
df.loc[df['Product'] == 'Bank account or service', 'Product'] = 'Other financial service'                                          
df = df[df.Product != 'Virtual currency']


MAX_NB_WORDS = 50000
# Max number of words in each complaint.
MAX_SEQUENCE_LENGTH = 250
# This is fixed.
EMBEDDING_DIM = 100
tokenizer = Tokenizer(num_words=MAX_NB_WORDS, filters='!"#$%&()*+,-./:;<=>?@[\]^_`{|}~', lower=True)
tokenizer.fit_on_texts(df['Consumer_complaint_narrative'].values)
word_index = tokenizer.word_index

loaded_model = pickle.load(open("syndhacklstm.sav",'rb'))
#below is important
"""new_complaint = ['I am a victim of identity theft and someone stole my identity and personal information to open up a Visa credit card account with Bank of America. The following Bank of America Visa credit card account do not belong to me : XXXX.']
new_complaint = ['Sir I want to know about the  interest rate on the current ongoing house loan']"""
new_complaint = ['I want to take education loan']

    
seq = tokenizer.texts_to_sequences(new_complaint)
padded = pad_sequences(seq, maxlen=MAX_SEQUENCE_LENGTH)
pred = loaded_model.predict(padded)
labels =['Consumer Loan','Credit Card','Other financial service']
#print(pred, labels[np.argmax(pred)])
check_t = pred
check = labels[np.argmax(pred)]


r = sr.Recognizer()

if __name__ == "__main__":
    patterns = "*.wav(2).wav"
    ignore_patterns = ""
    ignore_directories = False
    case_sensitive = True
    my_event_handler = PatternMatchingEventHandler(patterns, ignore_patterns, ignore_directories, case_sensitive)


def on_created(event):
    print(f"hey, {event.src_path} has been created!")
    with sr.AudioFile(event.src_path) as source: 
        audio = r.record(source) 
    complaint = []
    t2s = event.src_path
    t2s = t2s.split('_')
    #print(t2s)
    t2s = t2s[2].split('.wav')
    #print(t2s)
    p = "C:\\Users\\Dolar\\Desktop\\bank_d\\one\\routes\\bank_user\\complaints_text"
    t2s = p + "\\"+t2s[0]+'.txt' 
    #f.write(r.recognize_google(audio))
    try: 
        print("The audio file contains: " + r.recognize_google(audio))
        complaint.append(r.recognize_google(audio))
  
    except sr.UnknownValueError: 
        print("Google Speech Recognition could not understand audio") 
  
    except sr.RequestError as e: 
        print("Could not request results from Google Speech  Recognition service; {0}".format(e))
    
    seq = tokenizer.texts_to_sequences(complaint)
    #print (complaint)
    padded = pad_sequences(seq, maxlen=MAX_SEQUENCE_LENGTH)
    pred = loaded_model.predict(padded)
    labels =['Consumer Loan','Credit Card','Other financial service']
    department = labels[np.argmax(pred)]
    print("Hurray")
    with open(t2s,'w') as f:
        f.write(department)
        f.write('\n')
        f.write(complaint[0]) 
    #os.remove(event.src_path)
    print("Work Done")
    

my_event_handler.on_created = on_created


path = "C:\\Users\\Dolar\\Desktop\\bank_d\\one\\rec2\\uploads"
go_recursively = True
my_observer = Observer()
my_observer.schedule(my_event_handler, path, recursive=go_recursively)
print("Starting...")
my_observer.start()
try:
    while True:
        time.sleep(1)
except KeyboardInterrupt:
    my_observer.stop()
    my_observer.join()
