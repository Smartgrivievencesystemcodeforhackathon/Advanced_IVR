import {SET_USER} from '../actionTypes';
import {Apifetch,setToken} from '../../service/api'

export const newUser = (user)=>{
    return{
        type:SET_USER,
        user
    }
}

export const useToken = (token)=>{
      setToken(token);
}

export const addUser = (urlType,data)=>{
    return dispatch=>{
        return new Promise((resolve,reject)=>{
              return Apifetch("post",`http://localhost:8000/user/${urlType}`,data)
                        .then(({token,...user})=>{
                            localStorage.setItem("jwtToken",token);
                            useToken(token);
                            dispatch(newUser(user.data));
                            resolve();
                        }).catch(err=>reject(err))
        })
    }
}

export const logout = ()=>{
    return dispatch=>{
          dispatch(newUser({}));
          localStorage.clear();
    }
}