import {ISSUE} from '../actionTypes';
import {Apifetch} from '../../service/api'

export const Issueproblem = (data)=>{
    return{
        type:ISSUE,
        data
    }
}



export const Issue = (data,id)=>{
    return dispatch=>{
        return new Promise((resolve,reject)=>{
        return Apifetch("post",`http://localhost:8000/user/complaint/${id}/new`,data)
                .then(res=>{
                    dispatch(Issueproblem(res));
                    resolve();
                }).catch(err=>reject(err))
        })
    }
}

export const loginDepartment = (data)=>{
     return new Promise ((resolve,reject)=>{
             return   Apifetch("post",'http://localhost:9000/admin/login',data)
                          .then(res=>resolve(res.data))
                          .then(err=>reject(err))
     })
      
} 


export const statusPost = (id,data)=>{
  return new Promise((resolve,reject)=>{
        return Apifetch("post",`http://localhost:9000/admin/complaint/status/${id}`,data)
                      .then(res=>resolve(res))
                      .then(err=>reject(err))
  })
}