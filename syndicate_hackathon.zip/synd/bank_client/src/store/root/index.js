import {combineReducers} from 'redux';
import {department} from './department';
import {userReducer} from './user';
const rootReducer = combineReducers({
          set_user : userReducer,
          depart:department
})

export default rootReducer;