import {ISSUE} from '../actionTypes';


const DEFAULT_DEPARTMENT = {
  issue:{}
}

export const department = (state=DEFAULT_DEPARTMENT,action)=>{
       switch(action.type){
           
           case ISSUE : return{
               ...state,
             issue:action.data
           }

           default : return state;
       }
}