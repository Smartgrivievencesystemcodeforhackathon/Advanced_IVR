import React ,{Component} from 'react';

const LoanInfo = (props)=>{
       return(
           <div className="bar">
              <li> <h1>{props.loan.issue}</h1></li>
           </div>
       )
}

export default LoanInfo ;