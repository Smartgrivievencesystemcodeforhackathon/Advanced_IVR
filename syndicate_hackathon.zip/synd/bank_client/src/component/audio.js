import React,{Component} from 'react';

import {ReactMic} from 'react-mic';

class Record extends Component{
    constructor(props){
        super(props);
        this.state={
           isRecord:false
        }
        this.startRecord = this.startRecord.bind(this);
        this.stopRecord = this.stopRecord.bind(this);
    }
   startRecord(){
       this.setState({isRecord:true})
   }
   stopRecord(){
       this.setState({isRecord:false})
   }
   onData(recording){
   console.log(recording);
   }
   onStop(recording){
       console.log(recording);
   }

    render(){
        return(
            <div>
            <ReactMic
            record={this.state.isRecord}
            className="sound-wave"
            onStop={this.onStop}
            onData={this.onData}
            strokeColor="#000000"
            backgroundColor="#FF4081" />
        <button onClick={this.startRecord}>Start</button>
        <button onClick={this.stopRecord}>Stop</button>
        </div>
        )
    }
}

export default Record;