import React,{Component} from 'react';
import Axios from 'axios';
import {statusPost} from '../store/action/department';
import axios from 'axios';
import Moment from 'react-moment';
import '../admin.css'
class IssueConsole extends Component{
    constructor(props){
        super(props);
        this.state={
           complainStatus:false,
           email:"",
           user:{}
        }
    }
    status=()=>{
        this.setState({complainStatus:true})
             statusPost(this.props.id,this.state.complainStatus)
               .then(res=>alert("solved"))
               .catch(err=>console.log(err))
          window.location.reload()
    }
    
    componentDidMount(){
         console.log(this.props.user)
        axios.get(`http://localhost:8000/user/${this.props.user}`)
             .then(res=>this.setState({email:res.data.email,user:res.data}))
             .catch(err=>console.log(err))
    }

    details =()=>{
      Axios.get(`http://localhost:8000/user/${this.props.id}`)
        .then(res=>{console.log(res)})
        .catch(err=>console.log(err))
    }
    render(){
         console.log(this.state.user);
         if(this.props.id){
          return(
              <div className="card" style={{backgroundColor:"#e8eb49"}}>
            <div style={{marginLeft: "10%"}}>
                <nav className="dropdownmenu">
                <ul>
                  <li><a href="http://www.jochaho.com/wordpress/">Name: <b>{this.state.user.name}</b></a></li>
                  <li><a href="http://www.jochaho.com/wordpress/about-pritesh-badge/">Call At : <b>{this.state.user.mobileNo}</b></a></li>
                  <li><a href="#">More User Details</a>
                    <ul id="submenu">
                      <li>Adhar No. : <b>{this.state.user.adhar_no}</b></li>
                      <li>Zip Code : <b>{this.state.user.zip_code}</b></li>
                     
                    </ul>
                  </li>
                  <li><a href="http://www.jochaho.com/wordpress/category/news/">Complaint Date : <b><Moment format="YYYY/MM/DD">{this.state.user.date}</Moment></b></a></li>
                  <li><a href="http://www.jochaho.com/wordpress/about-pritesh-badge/">Account Type: <b>{this.state.user.acc_type}</b></a></li>
                </ul>
              </nav>
            </div>
            <h1> {"\n"} </h1>
            <div>
            <h3 style={{color:"blue", marginTop: "10%", textAlign: "center"}}> {this.props.issue} </h3>
            </div>

            <div>
              <label>
              <h4>Account No.</h4>
              <h4 style={{color:"green"}}>{this.state.user.accNo}</h4>
              </label>
            

            </div>
            <div className="row">
            <div className="col-md-6">
             {this.props.status_complain ? (<button  disabled  className="ui green button" >Solved</button>):
             ( <button className="btn btn-primary" onClick={this.status} >Solve</button>)}
           
            </div>
            <div className="col-md-6">
           <a href={`https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=${this.state.email}`}
                    target="_blank"><i className="fa fa-envelope fa-2x"></i></a>
            </div>
            </div>
        <hr></hr>
              </div>
            
          )}else{
            return(
             <div>
               <h1> No complain </h1>
             </div>
              )
          }
    }
}

export default IssueConsole