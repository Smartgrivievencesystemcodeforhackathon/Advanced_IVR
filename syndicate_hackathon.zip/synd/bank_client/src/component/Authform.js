import React, { Component } from "react";
import { Link } from "react-router-dom";
import { connect } from "react-redux";
import "../style.css";

class Authform extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      accNo: "",
      password: "",
      email: "",
      mobileNo: "",
      address: "",
      avtar: "",
      password2: ""
    };
  }

  handleChange = e => {
    this.setState({ [e.target.name]: e.target.value });
  };
  handleSubmit = e => {
    e.preventDefault();
    if (this.props.signUp) {
      this.props
        .newUser("signup", this.state)
        .then(res => this.props.history.push("/"))
        .catch(err => console.log(err));
    } else {
      this.props
        .newUser("signin", this.state)
        .then(res => this.props.history.push("/"))
        .catch(err => console.log(err));
    }
  };

  render() {
    if (this.props.signUp) {
      return (
        <div>
          <form onSubmit={this.handleSubmit}>
            <div className="cont">
              <div className="">
                <label>
                  <span>Name</span>
                  <input
                    type="text"
                    name="name"
                    placeholder="name"
                    value={this.state.name}
                    onChange={this.handleChange}
                  />
                </label>
                <label>
                  <span>Email</span>
                  <input
                    type="email"
                    name="email"
                    value={this.state.value}
                    onChange={this.handleChange}
                    placeholder="email"
                  />
                </label>
                <label>
                  <span>Account Number</span>
                  <input
                    type="text"
                    name="accNo"
                    value={this.state.accNo}
                    onChange={this.handleChange}
                    placeholder="account number"
                  />
                </label>
                <label>
                  <span>Password</span>
                  <input
                    type="password"
                    value={this.state.password}
                    name="password"
                    onChange={this.handleChange}
                    placeholder="password"
                  />
                </label>
                <label>
                  <span>Confirm Password</span>
                  <input
                    type="password"
                    name="password2"
                    onChange={this.handleChange}
                    placeholder="confirm password"
                    value={this.state.password2}
                  />
                </label>
                <button style={{
                  marginLeft: "35.5%",
                  marginTop: "1%"
                }} className="btn btn-primary">Sign Up</button>
              </div>
            </div>
          </form>
        </div>
      );
    } else {
      return (
        <div>
          <form onSubmit={this.handleSubmit}>
            <div className="cont">
              <div className="form sign-in">
                <h2>Welcome back,</h2>
                <label>
                  <span>Email</span>
                  <input
                    type="email"
                    name="email"
                    value={this.state.email}
                    onChange={this.handleChange}
                    placeholder="email"
                  />
                </label>
                <label>
                  <span>Password</span>
                  <input
                    type="password"
                    name="password"
                    value={this.state.password}
                    placeholder="password"
                    onChange={this.handleChange}
                  />
                </label>
                <p class="forgot-pass">Forgot password?</p>
                <button className="submit">Sign In</button>
                <Link to="/signup">
                  <button className="submit">Sign Up</button>
                </Link>
              </div>
              <div className="sub-cont">
                <div className="img">
                  <div className="img__text m--up">
                    <h2>New here?</h2>
                    <p>
                      Sign up and discover great amount of new opportunities!
                    </p>
                    <button style={{
                      marginTop: "150%",
                      marginRight: "50%"
                    }} className="ui orange button">
                      <h3>Sign Up</h3>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      );
    }
  }
}

export default Authform;
