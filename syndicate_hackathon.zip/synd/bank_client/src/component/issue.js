import React ,{Component} from 'react';
import {connect} from 'react-redux';
import {Issue} from '../store/action/department';
import axios  from 'axios'; 
import "../issueform.css"

class IssueProblem extends Component{
       constructor(props){
           super(props);
           this.state={
             
              user:"",
               department:"",
               description:"",
               status:false
           }
       }

// rending=()=>{
//   axios.get(`http://localhost:8000/user/audioComplaints/${this.props.id}/new`)
//        .then(res=>console.log("sucess"))
//        .catch(err=>console.log(err));
// }

handleChange = (e)=>{
      this.setState({[e.target.name]:e.target.value});
}
handleSubmit=(e)=>{
    e.preventDefault();
    this.setState({user:this.props.id})
    this.props.Issue(this.state,this.props.id);
    this.props.history.push('/');
}

       render(){
         console.log(this.props.id)
         if(this.props.id){
          return(
            <div>

                
                <h2>Complain Form</h2>

<div class="ui cards">
  <div id="form-main">
    <div id="form-div">
    <form onSubmit={this.handleSubmit}>
        
        <p className="name">
          <input
           name="department"
           value={this.state.department} 
           type="text"
            className="validate[required,custom[onlyLetter],length[0,100]] feedback-input" 
            placeholder="Department" 
            id="name"
           onChange={this.handleChange}
             />
           
        </p>
        
        <p className="text">
          <textarea 
          name="description"
           className="validate[required,length[10,1000]] feedback-input" 
           id="comment"
            placeholder="Write Complaint" 
            value={this.state.description}
            onChange={this.handleChange}
            />
        </p>
        
        
        <div className="submit">
          <input type="submit" value="SEND" id="button-blue"/>
          <div className="ease"></div>
        </div>


        <p className="text">
          <div className="submitAudio">
            <div style={{marginLeft: "35%"}}>
            </div>
            <button value="Record Complain" id="button-blue"> <a href="http://localhost:7000/"  target="_blank">Record Complain</a></button>
            <div className="ease"></div>
          </div>
        </p>
      </form>
  </div>
</div>

</div>
        </div>
           )
         }else{
           return(
             <div><h1>Please login first</h1></div>
           )
         }
           
       }
}



export default connect(null,{Issue})(IssueProblem);