import React,{Component} from 'react';

const SingleIssue = (props)=>{
  console.log(props.issue);

  if(props.issue){
           return(
               <div className="col-md-3">
            <div className="ui cards">
            <div className="card">
              <div className="content">
                <div className="header">
                  Complaint Dept <p>{props.issue.complainDept}</p>
                </div>
                <div className="description">
                  <p>{props.issue.complainDescription}</p>
                </div>
              </div>
              <div className="extra content">
                <div className="ui two buttons">
                  <div className="ui inverted blue button">Querry More</div>
                {props.issue.complainStatus===true ? (<div className="ui green button">Solved</div>):(<div className="ui red button">Unsolve</div>)}
                  
                }
                </div>
              </div>
            </div>
            </div>
            </div>
  
           )}else{
            return(
                  <div>
                  <h1>You have no previous complain</h1>
                  </div>
              )
           }
}

export default SingleIssue;