import React,{Component} from 'react';
import axios from 'axios';
import {loginDepartment} from '../store/action/department';
import IssueConsole from './issueconsole';
import "../department.css";

class Department extends Component{
    constructor(props){
        super(props);
        this.state={
            email:"",
            password:"",
            data:[],
            isTrue:false
        }
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this)

    }

    handleChange(e){
        this.setState({[e.target.name]:e.target.value})
    }

    handleSubmit(e){
        e.preventDefault();
       loginDepartment({email:this.state.email,password:this.state.password})
          .then(res=>
            {console.log(res)
                
               if(this.state.email==="admin-loan@gmail.com")
                    {
                        let loan1 = res.filter(r=>r.complainDept==="Consumer Loan\r")
                             console.log(loan1)
                              this.setState({data:loan1,isTrue:true}) ;
                    }
                    else if(this.state.email==="admin-credit@gmail.com"){
                          let credit = res.filter(r=>r.complainDept=== "Credit Card\r");
                          console.log(credit)
                          this.setState({data:credit,isTrue:true});
                    }
                   else if(this.state.email==="admin-kisan@gmail.com"){
                        let account = res.filter(r=>r.complainDept==="Other financial service\r")
                        this.setState({data:account,isTrue:true});
                    }

                
            
            })
          .catch(err=>console.log(err))

    }

    render(){
 
  
  let complain = this.state.data.map((r,i)=><IssueConsole  issue={r.complainDescription} key={i} id={r._id} status_complain={r.complainStatus} user={r.user}/>)
        
            
                 if(this.state.isTrue===false){return(<div>


                    <img id="img" src="https://image3.mouthshut.com/images/ImagesR/imageuser_l/2017/4/925004519-636832-1.png?rnd=88730" style={{height:"200px", width:"400px"}} />
                
                  <div id="fuck" className="login-page">
                    <div class="form">
                    
                      <form className="login-form" onSubmit={this.handleSubmit}>
                        <input 
                        type="text" 
                        value={this.state.email}
                        placeholder="email"
                        name="email"
                        onChange={this.handleChange}
                        />
                        <input
                         type="password"
                          placeholder="password"
                           name="password"
                           onChange={this.handleChange}
                           value={this.state.password}
                          />
                        <button>login</button>
                        <h4>Only For Registerd Bank Employees</h4>
                      </form>
                    </div>
                  </div>
                  </div>
                  )}
                  else{ if(this.state.data[0]){
                     return(
                        <ul> {complain} </ul>
                      )
                  }else{
                    return(
                      <div><h1 style={{color: 'red', marginLeft: "38%", marginTop: "15%"}}><b>No Complaints To Show</b></h1></div>)
                  }}
               
            
        }
    }


export default Department;