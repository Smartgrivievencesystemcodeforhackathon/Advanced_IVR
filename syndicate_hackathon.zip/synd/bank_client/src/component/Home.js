import React ,{Component} from 'react';
import {Link} from 'react-router-dom';
import axios from 'axios';

class Home extends Component {

    constructor(props){
        super(props);
    }

    rending=()=>{
  axios.get(`http://localhost:8000/user/audioComplaints/${this.props.id}/new`)
       .then(res=>console.log("sucess"))
       .catch(err=>console.log(err));
}
    
    render(){
      return(
          <div>
         <div className="card">
         <img src="https://img.icons8.com/ios-filled/100/000000/user-male-circle.png" alt="profile-image"/>
             <div className="row">
                 <div className="col-md-6">
                     <label htmlFor="Name">Name : </label>
                     </div>
                     <div className="col-md-6">
                     <p id="names">{this.props.user.name}</p>
                 </div>
             </div>
             <div className="row">
                 <div className="col-md-6">
                     <label htmlFor="accs">Account number : </label>
                     </div>
                     <div className="col-md-6">
                     <p id="accs">{this.props.user.accNo}</p>
                 </div>
             </div>
             <div className="row">
                 <div className="col-md-6">
                     <label htmlFor="emails">Email :</label>
                     </div>
                     <div className="col-md-6">
                     <p id="emails">{this.props.user.email}</p>
                 </div>
             </div>
         </div> 
         <div className="card">
             <div className="row">
                 <div className="col-md-3">
                 <button className=" massive ui inverted primary button">More Details</button>
                 </div>
                 <div className="col-md-3">
                 <button className=" massive ui inverted primary button">Register Complaints</button>
                 </div>
                 <div className="col-md-3">
                 <Link to="/user-dashboard"><button className=" massive ui inverted primary button">Previous Complaints</button></Link>
                 </div>
                 <div className="col-md-3">
                 {this.props.id ? (<button className=" massive ui inverted primary button" onClick={this.rending}>Upload audio</button>):(null)}
               
                 </div>
    
                 
                 
  </div>
         </div>
         </div>
      )
  }
}

export default Home;