import React ,{Component} from 'react';

const HomePage = ()=>{
	   return(
          <div style={{marginLeft: "25%", marginTop: "10%"}}>
          <img 
	          src="http://realtyplusmag.com/wp-content/uploads/2018/07/Syndicate-Bank-hikes-lending-rate-national.jpg" 
	          alt="homepage" />
          </div>
	   	)
}


export default HomePage;