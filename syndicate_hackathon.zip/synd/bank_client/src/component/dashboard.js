import React,{Component} from 'react';
import Axios from 'axios';
import SingleIssue from './singleIssue';

class Dashboard extends Component{
    constructor(props){
        super(props);
        this.state={
            userIssue:[]
        }
    }

 componentDidMount(){
      Axios.get(`http://localhost:8000/user/complaint/${this.props.id}`)
           .then(res=>this.setState({userIssue:res.data}))
           .catch(err=>console.log(err))
 }


    render(){
        console.log(this.state.userIssue)
        let allUserIssue  = this.state.userIssue.map((r,i)=><SingleIssue key={i}  issue={r}/>)
        return(
             <div className="row">
                 {allUserIssue}
             </div>
        )
    }
}

export default Dashboard;