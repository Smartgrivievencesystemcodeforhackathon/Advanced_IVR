import React ,{Component} from 'react';
import {Link} from 'react-router-dom';
import {connect} from 'react-redux';
import {logout} from '../store/action/user'
class Navbar extends Component{
    constructor(props){
        super(props);
    }

    logClear=(e)=>{
        e.preventDefault()
        this.props.logout();
       
    }

    render(){
        return(
            <div>
            <nav className="navbar navbar-inverse">
            <div className="container-fluid">
                <div className="navbar-header">
                <img src="https://currenthunt.com/wp-content/uploads/2019/04/Syndicate-Bank-logo-1.png" style={{height:"50px",width:"100px",borderRadius:"10px"}} alt="image" />
                </div>
                <ul className="nav navbar-nav navbar-right">
                <li  style={{color:"red"}}><Link to="/issue">Issue form</Link></li>
               
                <li className="item"><Link to="/">Home</Link></li>
                <li><Link to="/admin-login">Admin</Link></li>
                <li><a href="http://localhost:8000/about" target="_blank" >About</a></li>
                </ul>
               {this.props.isAuthenticated ? (
                   <ul className="nav navbar-nav navbar-right">
                      
                   <li><a href="#" onClick={this.logClear}>Logout</a></li>
                    <li ><Link to="/profile">Profile</Link></li>
                   </ul>
               ):(
                   <ul className="nav navbar-nav navbar-right">
                       
                        <li><Link to="/signup"><span className="glyphicon glyphicon-user"></span>SignUp</Link></li>
                 <li><Link to='/signin'><span className="glyphicon glyphicon-log-in"></span>Login</Link></li>
                   </ul>
               )}
                
                </div>
                </nav>
            </div>
        )
    }
}

function mapStateToProps(state){
    return{
        isAuthenticated:state.set_user.isAuthenticated
    }

}

export default connect(mapStateToProps,{logout})(Navbar);