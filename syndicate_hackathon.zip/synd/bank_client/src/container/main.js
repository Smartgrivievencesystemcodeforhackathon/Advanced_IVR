import React,{Component} from 'react';
import {connect} from 'react-redux'; 
import Navbar from './navbar';
import {Switch,Route,Link} from 'react-router-dom';
import Authform from '../component/Authform';
import IssueProblem from '../component/issue';
import Dashboard from '../component/dashboard';
import Record from '../component/audio'

import Home from '../component/Home';
import {addUser} from '../store/action/user';


import Department from '../component/department';
import About from '../component/about';
import HomePage from '../component/homefile'

class Main extends Component {
          constructor(props){
             super(props);
          }

          render(){
              console.log(this.props.user)
              return(
                
                    <Switch >
                        <Route exact path="/signin" render={props=><Authform {...props} newUser ={this.props.addUser}/>} />
                        <Route exact path="/signup" render={props=><Authform signUp {...props} newUser ={this.props.addUser}/>} />
                        <Route exact path="/profile"  render={props=><Home {...props} user={this.props.userDetail} id={this.props.user}/>} />
                        <Route exact path="/" render={props=> <HomePage />} />
                        <Route exact path="/issue" render={props=><IssueProblem {...props} id={this.props.user}/>} />
                       <Route exact path="/admin-login" render={props=><Department {...props} />} />
                       <Route exact path="/user-dashboard" render={props=><Dashboard id={this.props.user} {...props} />} />
                       <Route exact path="/record" render={props=><Record />}/>
                       <Route exact payh="/about" render={props=><About />} />
                    </Switch>
               

              )
          }
}

function mapStateToProps(state){
    return{
           user:state.set_user.user.id,
           userDetail:state.set_user.user
    }
}

export default connect(mapStateToProps,{addUser})(Main);