import React from 'react';
import {storeConfigure} from '../store'

import {Provider} from 'react-redux';
import {BrowserRouter} from 'react-router-dom';
import Main from './main';
import jwtDecode from 'jwt-decode';
import {newUser,useToken} from '../store/action/user';
import Navbar from './navbar'
import '../App.css'
const store = storeConfigure();
if(localStorage.jwtToken){
  useToken(localStorage.jwtToken);

  try{
      store.dispatch(newUser(jwtDecode(localStorage.jwtToken)))
  }catch(e){
    console.log(e)
      store.dispatch(newUser({}))
  }
}

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
   <div>
   <Navbar />
          <Main />    
   </div>
      
      </BrowserRouter>
    </Provider>
  );
}

export default App;
